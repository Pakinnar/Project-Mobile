import 'package:flutter/material.dart';
import 'pages/home_screen.dart';

void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Circle & Sphere Calculator',
      theme: ThemeData(primarySwatch: Colors.blue), // Global theme
      home: HomeScreen(), // Set HomeScreen as the main page
      
    );
  }
}
