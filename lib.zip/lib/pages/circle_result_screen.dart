import 'package:flutter/material.dart';
// Circle Result Page
class CircleResultScreen extends StatelessWidget {
  final double radius;
  
  CircleResultScreen({required this.radius});

  @override
  Widget build(BuildContext context) {
     //Task5: compute circumference and area of circle
    double circumference = 2 * 3.14159 * radius;
    double area = 3.14159 * radius * radius;

    return Scaffold(
      appBar: AppBar(title: Text('Circle Result')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Radius: $radius', style: TextStyle(fontSize: 18)),
            Text('Circumference: ${circumference.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
            Text('Area: ${area.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                  //Task06:  make the Back button return to the Home Screen using Navigator.pop()
                  Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}