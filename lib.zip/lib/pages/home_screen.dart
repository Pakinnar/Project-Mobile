import 'package:flutter/material.dart';
//Task 01: Import Required Screens
//import both circle_result_screen.dart and sphere_result_screen.dart.
import 'circle_result_screen.dart';
import 'sphere_result_screen.dart';

class HomeScreen extends StatefulWidget {
   const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Task 02: Implement a Text Field Controller
  // Create a TextEditingController.
  // Assign this controller to the TextField widget so it can read user input.
  final TextEditingController _radiusController = TextEditingController();
  
  // Default selection
  String _selectedOption = 'Circle';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Circle & Sphere Calculator')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _radiusController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter radius',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            Text("Select Shape:"),
            Row(
              children: [
                Radio(
                  value: 'Circle',
                  groupValue: _selectedOption,
                  onChanged: (value) {
                    //Task 03: Handle Radio Button Selection
                    //When the Circle radio button is selected, update _selectedOption using setState().
                    setState(() {
                      _selectedOption = value!;
                    });
                  },
                ),
                Text('Circle'),
                Radio(
                  value: 'Sphere',
                  groupValue: _selectedOption,
                  onChanged: (value) {
                    //Task 03: Handle Radio Button Selection
                    //When the Sphere radio button is selected, update _selectedOption using setState().
                    setState(() {
                      _selectedOption = value!;
                    });
                  },
                ),
                Text('Sphere'),
              ],
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                //
                onPressed: () {
                  //Task04: check condition that radius is not empty if so, show snackbar
                  //if circle radio is chosen route to page CircleResultScreen and pass radius to its constructor using Navigator.push()
                  //if sphere radio is chosen route to page SphereResultScreen and pass radius to its constructor using Navigator.push()
                  if (_radiusController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Please enter a radius')),
                    );
                  } else {
                    double? radius = double.tryParse(_radiusController.text);
                    if (radius == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Please enter a valid number')),
                      );
                      return;
                    }
                    if (_selectedOption == 'Circle') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CircleResultScreen(radius: radius)),
                      );
                    } else if (_selectedOption == 'Sphere') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SphereResultScreen(radius: radius)),
                      );
                    }
                  }
                },
                child: Text('Calculate'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}