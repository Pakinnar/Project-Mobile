import 'package:flutter/material.dart';
// Sphere Result Page
class SphereResultScreen extends StatelessWidget {
  final double radius;
  
  SphereResultScreen({required this.radius});

  @override
  Widget build(BuildContext context) {
    //Task5: compute surfaceArea and volume of sphere
    double surfaceArea = 4 * 3.14159 * radius * radius;
    double volume = (4 / 3) * 3.14159 * radius * radius * radius;

    return Scaffold(
      appBar: AppBar(title: Text('Sphere Result')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Radius: $radius', style: TextStyle(fontSize: 18)),
            Text('Surface Area: ${surfaceArea.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
            Text('Volume: ${volume.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                  //Task06: When click back using Navigator.pop to back to home screen
                  Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}