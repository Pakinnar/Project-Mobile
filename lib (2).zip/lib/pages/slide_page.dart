import 'package:flutter/material.dart';

const _bigText = TextStyle(fontSize: 64, fontWeight: FontWeight.bold);

class SlidePage extends StatefulWidget {
  static const route = '/slide';
  const SlidePage({super.key});
  @override
  State<SlidePage> createState() => _SlidePageState();
}

class _SlidePageState extends State<SlidePage> {
  final _dxCtrl = TextEditingController(text: '0');
  final _dyCtrl = TextEditingController(text: '0');

  double _dx = 0;
  double _dy = 0;
    onPressed() {
      setState(() {
        //Fill code here
        _dx = double.tryParse(_dxCtrl.text) ?? 0;
        _dy = double.tryParse(_dyCtrl.text) ?? 0;
      });
    }

  @override
  void dispose() {
    _dxCtrl.dispose();
    _dyCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Slide (Transform.translate)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _dxCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'dx (px)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _dyCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'dy (px)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: onPressed,
              child: const Text('Apply Translation'),
            ),
            const SizedBox(height: 24),
            Expanded(
                child: Transform.translate(
                  offset: Offset(_dx, _dy), //Fill code here
                  child: const Text('SAMPLE', style: _bigText),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
