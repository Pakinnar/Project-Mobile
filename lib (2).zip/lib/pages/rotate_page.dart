import 'dart:math' as math;
import 'package:flutter/material.dart';

const _bigText = TextStyle(fontSize: 64, fontWeight: FontWeight.bold);

class RotatePage extends StatefulWidget {
  static const route = '/rotate';
  const RotatePage({super.key});
  @override
  State<RotatePage> createState() => _RotatePageState();
}

class _RotatePageState extends State<RotatePage> {
  final _originXCtrl = TextEditingController(text: '0');
  final _originYCtrl = TextEditingController(text: '0');
  final _angleCtrl = TextEditingController(text: '45'); // degrees

  double _originX = 0;
  double _originY = 0;
  double _angleRad = 0; // radians
 
  onPressed() {
    setState(() {
      //Fill code here
      double angleDeg = double.tryParse(_angleCtrl.text) ?? 0;
      _angleRad = angleDeg * math.pi / 180; // Convert to radians
    });
  }

  @override
  void dispose() {
    _originXCtrl.dispose();
    _originYCtrl.dispose();
    _angleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rotate (Transform.rotate + origin)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _angleCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'angle (degrees)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
              FilledButton(
                onPressed: onPressed,
                child: const Text('Apply Rotation'),
              ),
            const SizedBox(height: 24),
            Expanded(
              child: Center(
                child: Transform.rotate(
                  angle: _angleRad,
                  origin: Offset(_originX, _originY),
                  child: const Text('SAMPLE', style: _bigText),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
