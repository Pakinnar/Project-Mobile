import 'package:flutter/material.dart';

const _bigText = TextStyle(fontSize: 64, fontWeight: FontWeight.bold);

class ScalePage extends StatefulWidget {
  static const route = '/scale';
  const ScalePage({super.key});
  @override
  State<ScalePage> createState() => _ScalePageState();
}

class _ScalePageState extends State<ScalePage> {
  final _scaleCtrl = TextEditingController(text: '1.0');

  double _scale = 1.0;

  onPressed() {
    setState(() {
      //Fill code here
      _scale = double.tryParse(_scaleCtrl.text) ?? 1.0;
    });
  }

  @override
  void dispose() {
    _scaleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scale (Transform.scale)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _scaleCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'scale (e.g., 1.2)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: onPressed,
              child: const Text('Apply Scale'),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: Center(
                child: Transform.scale(
                  scale: _scale, // Fill code here
                  child: const Text('SAMPLE', style: _bigText),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
