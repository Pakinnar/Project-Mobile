import 'package:flutter/material.dart';

const _bigText = TextStyle(fontSize: 64, fontWeight: FontWeight.bold);

class FadePage extends StatefulWidget {
  static const route = '/fade';
  const FadePage({super.key});
  @override
  State<FadePage> createState() => _FadePageState();
}

class _FadePageState extends State<FadePage> {
  final _opacityCtrl = TextEditingController(text: '1.0');

  double _opacity = 1.0;

  @override
  void dispose() {
    _opacityCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fade (Opacity widget)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _opacityCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'opacity (0.0 ~ 1.0)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                //Fill code here
                setState(() {
                    _opacity = double.tryParse(_opacityCtrl.text) ?? 1.0;
                  });
              },
              child: const Text('Apply Opacity'),
            ),
            const SizedBox(height: 24),
            Expanded(
                child: Opacity(
                  opacity: _opacity,
                  child: const Text('SAMPLE', style: _bigText),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
