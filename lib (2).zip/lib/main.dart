import 'package:flutter/material.dart';
import 'pages/scale_page.dart';
import 'pages/fade_page.dart';
import 'pages/slide_page.dart';
import 'pages/rotate_page.dart';

void main() => runApp(const TransformBasicsApp());

class TransformBasicsApp extends StatelessWidget {
  const TransformBasicsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Transform Basics (no animation)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
      routes: {
        ScalePage.route: (_) => const ScalePage(),
        FadePage.route: (_) => const FadePage(),
        SlidePage.route: (_) => const SlidePage(),
        RotatePage.route: (_) => const RotatePage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transform Basics (Press button to apply)'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            FilledButton(
              onPressed: () => Navigator.pushNamed(context, ScalePage.route),
              child: const Text('Scale Page'),
            ),
            FilledButton(
              onPressed: () => Navigator.pushNamed(context, FadePage.route),
              child: const Text('Fade (Opacity) Page'),
            ),
            FilledButton(
              onPressed: () => Navigator.pushNamed(context, SlidePage.route),
              child: const Text('Slide (Translate) Page'),
            ),
            FilledButton(
              onPressed: () => Navigator.pushNamed(context, RotatePage.route),
              child: const Text('Rotate Page'),
            ),
          ],
        ),
      ),
    );
  }
}
